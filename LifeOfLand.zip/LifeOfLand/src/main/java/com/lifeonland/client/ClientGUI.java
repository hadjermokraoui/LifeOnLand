package com.lifeonland.client;
import com.lifeonland.utils.ServiceDiscovery;
import com.lifeonland.wildlife.*;
import com.lifeonland.fire.*;
import com.lifeonland.poacher.*;
import javax.swing.JFrame;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import javax.jmdns.ServiceInfo;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.net.InetAddress;

public class ClientGUI extends JFrame {
	


    private final JTextArea responseArea = new JTextArea(10, 40);

    public ClientGUI() {
        setTitle("Smart Reserve Client");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Wildlife Tracker", createWildlifePanel());
        tabs.addTab("Forest Fire Detection", createFirePanel());
        tabs.addTab("Poacher Detection", createPoacherPanel());

        add(tabs, BorderLayout.CENTER);
        responseArea.setEditable(false);
        add(new JScrollPane(responseArea), BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }
    
    // ------------ Wildlife Panel -----------------
    private JPanel createWildlifePanel() {
        JPanel panel = new JPanel(new GridLayout(5, 2));
        JTextField animalId = new JTextField();
        JTextField lat = new JTextField();
        JTextField lon = new JTextField();

        panel.add(new JLabel("Animal ID:")); panel.add(animalId);
        panel.add(new JLabel("Latitude:"));  panel.add(lat);
        panel.add(new JLabel("Longitude:")); panel.add(lon);
        panel.add(new JLabel(" ")); panel.add(new JLabel(""));

        JButton sendBtn = new JButton("Track Location");
        sendBtn.addActionListener((ActionEvent e) -> {
            try {
                ServiceDiscovery.discoverService("_wildlife._tcp.local.");
                ServiceInfo serviceInfo = ServiceDiscovery.getServiceInfo("_wildlife._tcp.local.");
                if (serviceInfo != null) {
                    ManagedChannel channel = ManagedChannelBuilder
                            .forAddress(serviceInfo.getHostAddresses()[0], serviceInfo.getPort())
                            .usePlaintext()
                            .build();

                    WildlifeTrackerGrpc.WildlifeTrackerBlockingStub stub =
                            WildlifeTrackerGrpc.newBlockingStub(channel);

                    AnimalLocationRequest req = AnimalLocationRequest.newBuilder()
                            .setAnimalId(animalId.getText())
                            .setLatitude(Double.parseDouble(lat.getText()))
                            .setLongitude(Double.parseDouble(lon.getText()))
                            .setTime("2025-07-31T14:00")
                            .build();

                    AnimalLocationResponse res = stub.trackAnimalLocation(req);
                    responseArea.setText(res.getMessage());
                    channel.shutdown();
                } else {
                    responseArea.setText("Wildlife service not found.");
                }
            } catch (Exception ex) {
                responseArea.setText("Error: " + ex.getMessage());
                ex.printStackTrace();
            }
        });

        panel.add(sendBtn);
        return panel;
    }

    // ------------ Forest Fire Panel -----------------
    private JPanel createFirePanel() {
        JPanel panel = new JPanel(new GridLayout(4, 2));
        JTextField sensorId = new JTextField();
        JTextField temp = new JTextField();
        JTextField humidity = new JTextField();

        panel.add(new JLabel("Sensor ID:"));   panel.add(sensorId);
        panel.add(new JLabel("Temperature:")); panel.add(temp);
        panel.add(new JLabel("Humidity:"));    panel.add(humidity);

JButton sendBtn = new JButton("Report Sensor Data");
        sendBtn.addActionListener((ActionEvent e) -> {
            try {
                ServiceDiscovery.discoverService("_fire._tcp.local.");
                ServiceInfo serviceInfo = ServiceDiscovery.getServiceInfo("_fire._tcp.local.");
                if (serviceInfo != null) {
                    ManagedChannel channel = ManagedChannelBuilder
                            .forAddress(serviceInfo.getHostAddresses()[0], serviceInfo.getPort())
                            .usePlaintext()
                            .build();

                    FireDetectionGrpc.FireDetectionBlockingStub stub =
                            FireDetectionGrpc.newBlockingStub(channel);

                    SensorDataRequest req = SensorDataRequest.newBuilder()
                            .setSensorId(sensorId.getText())
                            .setTemperature(Float.parseFloat(temp.getText()))
                            .setHumidity(Float.parseFloat(humidity.getText()))
                            .setTime("2025-07-31T14:10")
                            .build();

                    SensorDataResponse res = stub.reportSensorData(req);
                    responseArea.setText(res.getMessage());
                    channel.shutdown();
                } else {
                    responseArea.setText("Fire service not found.");
                }
            } catch (Exception ex) {
                responseArea.setText("Error: " + ex.getMessage());
                ex.printStackTrace();
            }
        });

        panel.add(sendBtn);
        return panel;
    }

    // ------------ Poacher Panel -----------------
    private JPanel createPoacherPanel() {
        JPanel panel = new JPanel(new GridLayout(5, 2));
        JTextField cameraId = new JTextField();
        JTextField lat = new JTextField();
        JTextField lon = new JTextField();
        JTextField confidence = new JTextField();

        panel.add(new JLabel("Camera ID:"));     panel.add(cameraId);
        panel.add(new JLabel("Latitude:"));      panel.add(lat);
        panel.add(new JLabel("Longitude:"));     panel.add(lon);
        panel.add(new JLabel("Confidence (%):"));panel.add(confidence);

        JButton sendBtn = new JButton("Detect Intrusion");
        sendBtn.addActionListener((ActionEvent e) -> {
            try {
                ServiceDiscovery.discoverService("_poacher._tcp.local.");
                ServiceInfo serviceInfo = ServiceDiscovery.getServiceInfo("_poacher._tcp.local.");
                if (serviceInfo != null) {
                    ManagedChannel channel = ManagedChannelBuilder
                            .forAddress(serviceInfo.getHostAddresses()[0], serviceInfo.getPort())
                            .usePlaintext()
                            .build();

                    PoacherDetectionGrpc.PoacherDetectionBlockingStub stub =
                            PoacherDetectionGrpc.newBlockingStub(channel);

                    IntrusionRequest req = IntrusionRequest.newBuilder()
                            .setCameraId(cameraId.getText())
                            .setLatitude(Double.parseDouble(lat.getText()))
                            .setLongitude(Double.parseDouble(lon.getText()))
                            .setConfidenceLevel(Float.parseFloat(confidence.getText()))
                            .setTime("2025-07-31T14:15")
                            .build();

                    IntrusionResponse res = stub.detectIntrusion(req);
                    responseArea.setText(res.getMessage());
                    channel.shutdown();
                } else {
                    responseArea.setText("Poacher service not found.");
                }
            } catch (Exception ex) {
                responseArea.setText("Error: " + ex.getMessage());
                ex.printStackTrace();
            }
        });

        panel.add(sendBtn);
        return panel;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new ClientGUI();
            }
        });
    }
}