package com.lifeonland.poacher;

import java.io.IOException;
import java.net.InetAddress;
import java.util.logging.Logger;

import javax.jmdns.JmDNS;
import javax.jmdns.ServiceInfo;

import com.lifeonland.utils.ServiceRegister;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;


// Import generated classes from .proto
import com.lifeonland.poacher.PoacherDetectionProto;
import com.lifeonland.poacher.PoacherDetectionGrpc;
import com.lifeonland.poacher.IntrusionRequest;
import com.lifeonland.poacher.IntrusionResponse;



public class PoacherDetectionServer extends PoacherDetectionGrpc.PoacherDetectionImplBase {
	
	
	private static final Logger logger = Logger.getLogger(PoacherDetectionServer.class.getName());
	
	public static void main(String[] args) throws IOException, InterruptedException {
		
		PoacherDetectionServer trackerServer = new PoacherDetectionServer();
	 
		int port = 50053;
		
		try {
		
	        Server server = ServerBuilder.forPort(50053)
	                .addService(new PoacherDetectionServer())
	                .build()
	                .start();

	        System.out.println("PoacherDetectionService started on port 50053");
	     // Register with jmDNS
		       ServiceRegister.register("_poacher._tcp.local.", "Poacher Detection", port);

	        server.awaitTermination();

			 
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
	    logger.info("Server started, listening on " + port);
	    		    
	   
	}



        @Override
        public void detectIntrusion(IntrusionRequest request, StreamObserver<IntrusionResponse> responseObserver) {
            float confidence = request.getConfidenceLevel();
            boolean alert = confidence >= 90.0;

            String message = alert
                    ? "🚨 Possible human intrusion detected near camera " + request.getCameraId() + "!"
                    : "No suspicious movement detected.";

            IntrusionResponse response = IntrusionResponse.newBuilder()
                    .setAlert(alert)
                    .setMessage(message)
                    .build();

            responseObserver.onNext(response);
            responseObserver.onCompleted();
        }
    }
