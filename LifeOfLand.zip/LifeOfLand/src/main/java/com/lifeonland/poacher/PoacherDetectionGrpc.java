package com.lifeonland.poacher;

import static io.grpc.MethodDescriptor.generateFullMethodName;
import static io.grpc.stub.ClientCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ClientCalls.asyncClientStreamingCall;
import static io.grpc.stub.ClientCalls.asyncServerStreamingCall;
import static io.grpc.stub.ClientCalls.asyncUnaryCall;
import static io.grpc.stub.ClientCalls.blockingServerStreamingCall;
import static io.grpc.stub.ClientCalls.blockingUnaryCall;
import static io.grpc.stub.ClientCalls.futureUnaryCall;
import static io.grpc.stub.ServerCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ServerCalls.asyncClientStreamingCall;
import static io.grpc.stub.ServerCalls.asyncServerStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

/**
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.15.0)",
    comments = "Source: service3.proto")
public final class PoacherDetectionGrpc {

  private PoacherDetectionGrpc() {}

  public static final String SERVICE_NAME = "service3.PoacherDetection";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.lifeonland.poacher.IntrusionRequest,
      com.lifeonland.poacher.IntrusionResponse> getDetectIntrusionMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DetectIntrusion",
      requestType = com.lifeonland.poacher.IntrusionRequest.class,
      responseType = com.lifeonland.poacher.IntrusionResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.lifeonland.poacher.IntrusionRequest,
      com.lifeonland.poacher.IntrusionResponse> getDetectIntrusionMethod() {
    io.grpc.MethodDescriptor<com.lifeonland.poacher.IntrusionRequest, com.lifeonland.poacher.IntrusionResponse> getDetectIntrusionMethod;
    if ((getDetectIntrusionMethod = PoacherDetectionGrpc.getDetectIntrusionMethod) == null) {
      synchronized (PoacherDetectionGrpc.class) {
        if ((getDetectIntrusionMethod = PoacherDetectionGrpc.getDetectIntrusionMethod) == null) {
          PoacherDetectionGrpc.getDetectIntrusionMethod = getDetectIntrusionMethod = 
              io.grpc.MethodDescriptor.<com.lifeonland.poacher.IntrusionRequest, com.lifeonland.poacher.IntrusionResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "service3.PoacherDetection", "DetectIntrusion"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.lifeonland.poacher.IntrusionRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.lifeonland.poacher.IntrusionResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new PoacherDetectionMethodDescriptorSupplier("DetectIntrusion"))
                  .build();
          }
        }
     }
     return getDetectIntrusionMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static PoacherDetectionStub newStub(io.grpc.Channel channel) {
    return new PoacherDetectionStub(channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static PoacherDetectionBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    return new PoacherDetectionBlockingStub(channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static PoacherDetectionFutureStub newFutureStub(
      io.grpc.Channel channel) {
    return new PoacherDetectionFutureStub(channel);
  }

  /**
   */
  public static abstract class PoacherDetectionImplBase implements io.grpc.BindableService {

    /**
     */
    public void detectIntrusion(com.lifeonland.poacher.IntrusionRequest request,
        io.grpc.stub.StreamObserver<com.lifeonland.poacher.IntrusionResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getDetectIntrusionMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getDetectIntrusionMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                com.lifeonland.poacher.IntrusionRequest,
                com.lifeonland.poacher.IntrusionResponse>(
                  this, METHODID_DETECT_INTRUSION)))
          .build();
    }
  }

  /**
   */
  public static final class PoacherDetectionStub extends io.grpc.stub.AbstractStub<PoacherDetectionStub> {
    private PoacherDetectionStub(io.grpc.Channel channel) {
      super(channel);
    }

    private PoacherDetectionStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected PoacherDetectionStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new PoacherDetectionStub(channel, callOptions);
    }

    /**
     */
    public void detectIntrusion(com.lifeonland.poacher.IntrusionRequest request,
        io.grpc.stub.StreamObserver<com.lifeonland.poacher.IntrusionResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getDetectIntrusionMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   */
  public static final class PoacherDetectionBlockingStub extends io.grpc.stub.AbstractStub<PoacherDetectionBlockingStub> {
    private PoacherDetectionBlockingStub(io.grpc.Channel channel) {
      super(channel);
    }

    private PoacherDetectionBlockingStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected PoacherDetectionBlockingStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new PoacherDetectionBlockingStub(channel, callOptions);
    }

    /**
     */
    public com.lifeonland.poacher.IntrusionResponse detectIntrusion(com.lifeonland.poacher.IntrusionRequest request) {
      return blockingUnaryCall(
          getChannel(), getDetectIntrusionMethod(), getCallOptions(), request);
    }
  }

  /**
   */
  public static final class PoacherDetectionFutureStub extends io.grpc.stub.AbstractStub<PoacherDetectionFutureStub> {
    private PoacherDetectionFutureStub(io.grpc.Channel channel) {
      super(channel);
    }

    private PoacherDetectionFutureStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected PoacherDetectionFutureStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new PoacherDetectionFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.lifeonland.poacher.IntrusionResponse> detectIntrusion(
        com.lifeonland.poacher.IntrusionRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getDetectIntrusionMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_DETECT_INTRUSION = 0;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final PoacherDetectionImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(PoacherDetectionImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_DETECT_INTRUSION:
          serviceImpl.detectIntrusion((com.lifeonland.poacher.IntrusionRequest) request,
              (io.grpc.stub.StreamObserver<com.lifeonland.poacher.IntrusionResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class PoacherDetectionBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    PoacherDetectionBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return com.lifeonland.poacher.PoacherDetectionProto.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("PoacherDetection");
    }
  }

  private static final class PoacherDetectionFileDescriptorSupplier
      extends PoacherDetectionBaseDescriptorSupplier {
    PoacherDetectionFileDescriptorSupplier() {}
  }

  private static final class PoacherDetectionMethodDescriptorSupplier
      extends PoacherDetectionBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    PoacherDetectionMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (PoacherDetectionGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new PoacherDetectionFileDescriptorSupplier())
              .addMethod(getDetectIntrusionMethod())
              .build();
        }
      }
    }
    return result;
  }
}
