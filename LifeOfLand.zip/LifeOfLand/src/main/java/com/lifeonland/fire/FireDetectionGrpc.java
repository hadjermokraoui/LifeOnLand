package com.lifeonland.fire;

import static io.grpc.MethodDescriptor.generateFullMethodName;
import static io.grpc.stub.ClientCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ClientCalls.asyncClientStreamingCall;
import static io.grpc.stub.ClientCalls.asyncServerStreamingCall;
import static io.grpc.stub.ClientCalls.asyncUnaryCall;
import static io.grpc.stub.ClientCalls.blockingServerStreamingCall;
import static io.grpc.stub.ClientCalls.blockingUnaryCall;
import static io.grpc.stub.ClientCalls.futureUnaryCall;
import static io.grpc.stub.ServerCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ServerCalls.asyncClientStreamingCall;
import static io.grpc.stub.ServerCalls.asyncServerStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

/**
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.15.0)",
    comments = "Source: service2.proto")
public final class FireDetectionGrpc {

  private FireDetectionGrpc() {}

  public static final String SERVICE_NAME = "service2.FireDetection";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.lifeonland.fire.SensorDataRequest,
      com.lifeonland.fire.SensorDataResponse> getReportSensorDataMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ReportSensorData",
      requestType = com.lifeonland.fire.SensorDataRequest.class,
      responseType = com.lifeonland.fire.SensorDataResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.lifeonland.fire.SensorDataRequest,
      com.lifeonland.fire.SensorDataResponse> getReportSensorDataMethod() {
    io.grpc.MethodDescriptor<com.lifeonland.fire.SensorDataRequest, com.lifeonland.fire.SensorDataResponse> getReportSensorDataMethod;
    if ((getReportSensorDataMethod = FireDetectionGrpc.getReportSensorDataMethod) == null) {
      synchronized (FireDetectionGrpc.class) {
        if ((getReportSensorDataMethod = FireDetectionGrpc.getReportSensorDataMethod) == null) {
          FireDetectionGrpc.getReportSensorDataMethod = getReportSensorDataMethod = 
              io.grpc.MethodDescriptor.<com.lifeonland.fire.SensorDataRequest, com.lifeonland.fire.SensorDataResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "service2.FireDetection", "ReportSensorData"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.lifeonland.fire.SensorDataRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.lifeonland.fire.SensorDataResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new FireDetectionMethodDescriptorSupplier("ReportSensorData"))
                  .build();
          }
        }
     }
     return getReportSensorDataMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static FireDetectionStub newStub(io.grpc.Channel channel) {
    return new FireDetectionStub(channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static FireDetectionBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    return new FireDetectionBlockingStub(channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static FireDetectionFutureStub newFutureStub(
      io.grpc.Channel channel) {
    return new FireDetectionFutureStub(channel);
  }

  /**
   */
  public static abstract class FireDetectionImplBase implements io.grpc.BindableService {

    /**
     */
    public void reportSensorData(com.lifeonland.fire.SensorDataRequest request,
        io.grpc.stub.StreamObserver<com.lifeonland.fire.SensorDataResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getReportSensorDataMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getReportSensorDataMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                com.lifeonland.fire.SensorDataRequest,
                com.lifeonland.fire.SensorDataResponse>(
                  this, METHODID_REPORT_SENSOR_DATA)))
          .build();
    }
  }

  /**
   */
  public static final class FireDetectionStub extends io.grpc.stub.AbstractStub<FireDetectionStub> {
    private FireDetectionStub(io.grpc.Channel channel) {
      super(channel);
    }

    private FireDetectionStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected FireDetectionStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new FireDetectionStub(channel, callOptions);
    }

    /**
     */
    public void reportSensorData(com.lifeonland.fire.SensorDataRequest request,
        io.grpc.stub.StreamObserver<com.lifeonland.fire.SensorDataResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getReportSensorDataMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   */
  public static final class FireDetectionBlockingStub extends io.grpc.stub.AbstractStub<FireDetectionBlockingStub> {
    private FireDetectionBlockingStub(io.grpc.Channel channel) {
      super(channel);
    }

    private FireDetectionBlockingStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected FireDetectionBlockingStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new FireDetectionBlockingStub(channel, callOptions);
    }

    /**
     */
    public com.lifeonland.fire.SensorDataResponse reportSensorData(com.lifeonland.fire.SensorDataRequest request) {
      return blockingUnaryCall(
          getChannel(), getReportSensorDataMethod(), getCallOptions(), request);
    }
  }

  /**
   */
  public static final class FireDetectionFutureStub extends io.grpc.stub.AbstractStub<FireDetectionFutureStub> {
    private FireDetectionFutureStub(io.grpc.Channel channel) {
      super(channel);
    }

    private FireDetectionFutureStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected FireDetectionFutureStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new FireDetectionFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.lifeonland.fire.SensorDataResponse> reportSensorData(
        com.lifeonland.fire.SensorDataRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getReportSensorDataMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_REPORT_SENSOR_DATA = 0;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final FireDetectionImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(FireDetectionImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_REPORT_SENSOR_DATA:
          serviceImpl.reportSensorData((com.lifeonland.fire.SensorDataRequest) request,
              (io.grpc.stub.StreamObserver<com.lifeonland.fire.SensorDataResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class FireDetectionBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    FireDetectionBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return com.lifeonland.fire.FireDetectionProto.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("FireDetection");
    }
  }

  private static final class FireDetectionFileDescriptorSupplier
      extends FireDetectionBaseDescriptorSupplier {
    FireDetectionFileDescriptorSupplier() {}
  }

  private static final class FireDetectionMethodDescriptorSupplier
      extends FireDetectionBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    FireDetectionMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (FireDetectionGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new FireDetectionFileDescriptorSupplier())
              .addMethod(getReportSensorDataMethod())
              .build();
        }
      }
    }
    return result;
  }
}
