package com.lifeonland.fire;


import com.lifeonland.utils.ServiceRegister;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;
import java.io.IOException;
import java.net.InetAddress;
import java.util.logging.Logger;

import javax.jmdns.JmDNS;
import javax.jmdns.ServiceInfo;

// Import generated classes from .proto
import com.lifeonland.fire.FireDetectionGrpc;
import com.lifeonland.fire.SensorDataRequest;
import com.lifeonland.fire.SensorDataResponse;

public class FireDetectionServer extends FireDetectionGrpc.FireDetectionImplBase {
	
	
	private static final Logger logger = Logger.getLogger(FireDetectionServer.class.getName());
	
	public static void main(String[] args) throws IOException, InterruptedException {
		
		FireDetectionServer fireDetectionServer = new FireDetectionServer();
	 
		int port = 50052;
		
		
		try {
	        Server server = ServerBuilder.forPort(50052)
	                .addService(new FireDetectionServer())
	                .build()
	                .start();

	        System.out.println("FireDetectionService started on port 50052");
	        // Register with jmDNS
		       ServiceRegister.register("_fire._tcp.local.", "Fire Detection", port);
	        server.awaitTermination();

			 
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
	    logger.info("Server started, listening on " + port);
	    		    
	   
	}

        @Override
        public void reportSensorData(SensorDataRequest request, StreamObserver<SensorDataResponse> responseObserver) {
            float temp = request.getTemperature();
            float humidity = request.getHumidity();

            boolean alert = temp > 45.0 && humidity < 20.0;

            String message = alert
                    ? "🔥 Potential fire detected near sensor " + request.getSensorId() + "!"
                    : "✅ No fire risk near sensor " + request.getSensorId() + ".";

            SensorDataResponse response = SensorDataResponse.newBuilder()
                    .setAlert(alert)
                    .setMessage(message)
                    .build();

            responseObserver.onNext(response);
            responseObserver.onCompleted();
        }
    }
