package com.lifeonland.utils;

import java.io.IOException;
import java.net.InetAddress;
import javax.jmdns.JmDNS;
import javax.jmdns.ServiceInfo;
public class ServiceRegister {

		
	private static JmDNS jmdns;

    public static void register(String serviceType, String serviceName, int port) {
        try {
            InetAddress addr = InetAddress.getLocalHost();
            jmdns = JmDNS.create(addr);

            System.out.println("Registering service on: " + addr.getHostAddress());

            ServiceInfo serviceInfo = ServiceInfo.create(serviceType, serviceName, port, "reserve-service");
            jmdns.registerService(serviceInfo);

            System.out.printf("✅ Registered: %s (%s) on port %d\n", serviceName, serviceType, port);

        } catch (IOException e) {
            System.err.println("❌ Service registration failed: " + e.getMessage());
        }
    }

    public static void unregisterAll() {
        if (jmdns != null) {
            jmdns.unregisterAllServices();
            System.out.println("🛑 All services unregistered.");
        }
    }
}