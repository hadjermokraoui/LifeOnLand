package com.lifeonland.utils;

import com.lifeonland.wildlife.*;
import com.lifeonland.fire.*;
import com.lifeonland.poacher.*;
import com.lifeonland.client.*;
import javax.jmdns.JmDNS;
import javax.jmdns.ServiceInfo;
import javax.jmdns.ServiceEvent;
import javax.jmdns.ServiceListener;
import java.io.IOException;
import java.net.InetAddress;
import java.util.concurrent.ConcurrentHashMap;
//This code is adapted from https://github.com/jmdns/jmdns
public class ServiceDiscovery {
	private static final ConcurrentHashMap<String, ServiceInfo> serviceCache = new ConcurrentHashMap<>();

    public static void discoverService(String serviceType) {
        try {
            JmDNS jmdns = JmDNS.create(InetAddress.getLocalHost());

            jmdns.addServiceListener(serviceType, new ServiceListener() {

                @Override
                public void serviceAdded(ServiceEvent event) {
                    System.out.println("Service added: " + event.getName());
                    // Request more info to trigger resolution
                    jmdns.requestServiceInfo(event.getType(), event.getName(), 1);
                }

                @Override
                public void serviceRemoved(ServiceEvent event) {
                    System.out.println("Service removed: " + event.getName());
                    serviceCache.remove(serviceType);
                }

                @Override
                public void serviceResolved(ServiceEvent event) {
                    ServiceInfo info = event.getInfo();
                    System.out.println("Service resolved: " + info.getQualifiedName() + " -> " +
                            info.getHostAddresses()[0] + ":" + info.getPort());

                    // Save to cache for access from GUI
                    serviceCache.put(serviceType, info);
                }
            });

            // Let the discovery happen (short delay)
            Thread.sleep(1500);

        } catch (IOException | InterruptedException e) {
            System.err.println("Service discovery error: " + e.getMessage());
        }
    }

    public static ServiceInfo getServiceInfo(String serviceType) {
        return serviceCache.get(serviceType);
    }
}            