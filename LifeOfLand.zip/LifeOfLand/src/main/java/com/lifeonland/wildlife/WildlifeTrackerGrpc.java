package com.lifeonland.wildlife;

import static io.grpc.MethodDescriptor.generateFullMethodName;
import static io.grpc.stub.ClientCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ClientCalls.asyncClientStreamingCall;
import static io.grpc.stub.ClientCalls.asyncServerStreamingCall;
import static io.grpc.stub.ClientCalls.asyncUnaryCall;
import static io.grpc.stub.ClientCalls.blockingServerStreamingCall;
import static io.grpc.stub.ClientCalls.blockingUnaryCall;
import static io.grpc.stub.ClientCalls.futureUnaryCall;
import static io.grpc.stub.ServerCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ServerCalls.asyncClientStreamingCall;
import static io.grpc.stub.ServerCalls.asyncServerStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

/**
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.15.0)",
    comments = "Source: serivce1.proto")
public final class WildlifeTrackerGrpc {

  private WildlifeTrackerGrpc() {}

  public static final String SERVICE_NAME = "service1.WildlifeTracker";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.lifeonland.wildlife.AnimalLocationRequest,
      com.lifeonland.wildlife.AnimalLocationResponse> getTrackAnimalLocationMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "TrackAnimalLocation",
      requestType = com.lifeonland.wildlife.AnimalLocationRequest.class,
      responseType = com.lifeonland.wildlife.AnimalLocationResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.lifeonland.wildlife.AnimalLocationRequest,
      com.lifeonland.wildlife.AnimalLocationResponse> getTrackAnimalLocationMethod() {
    io.grpc.MethodDescriptor<com.lifeonland.wildlife.AnimalLocationRequest, com.lifeonland.wildlife.AnimalLocationResponse> getTrackAnimalLocationMethod;
    if ((getTrackAnimalLocationMethod = WildlifeTrackerGrpc.getTrackAnimalLocationMethod) == null) {
      synchronized (WildlifeTrackerGrpc.class) {
        if ((getTrackAnimalLocationMethod = WildlifeTrackerGrpc.getTrackAnimalLocationMethod) == null) {
          WildlifeTrackerGrpc.getTrackAnimalLocationMethod = getTrackAnimalLocationMethod = 
              io.grpc.MethodDescriptor.<com.lifeonland.wildlife.AnimalLocationRequest, com.lifeonland.wildlife.AnimalLocationResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "service1.WildlifeTracker", "TrackAnimalLocation"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.lifeonland.wildlife.AnimalLocationRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.lifeonland.wildlife.AnimalLocationResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new WildlifeTrackerMethodDescriptorSupplier("TrackAnimalLocation"))
                  .build();
          }
        }
     }
     return getTrackAnimalLocationMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.lifeonland.wildlife.AnimalLocationRequest,
      com.lifeonland.wildlife.AnimalLocationResponse> getStreamAnimalLocationsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "StreamAnimalLocations",
      requestType = com.lifeonland.wildlife.AnimalLocationRequest.class,
      responseType = com.lifeonland.wildlife.AnimalLocationResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.BIDI_STREAMING)
  public static io.grpc.MethodDescriptor<com.lifeonland.wildlife.AnimalLocationRequest,
      com.lifeonland.wildlife.AnimalLocationResponse> getStreamAnimalLocationsMethod() {
    io.grpc.MethodDescriptor<com.lifeonland.wildlife.AnimalLocationRequest, com.lifeonland.wildlife.AnimalLocationResponse> getStreamAnimalLocationsMethod;
    if ((getStreamAnimalLocationsMethod = WildlifeTrackerGrpc.getStreamAnimalLocationsMethod) == null) {
      synchronized (WildlifeTrackerGrpc.class) {
        if ((getStreamAnimalLocationsMethod = WildlifeTrackerGrpc.getStreamAnimalLocationsMethod) == null) {
          WildlifeTrackerGrpc.getStreamAnimalLocationsMethod = getStreamAnimalLocationsMethod = 
              io.grpc.MethodDescriptor.<com.lifeonland.wildlife.AnimalLocationRequest, com.lifeonland.wildlife.AnimalLocationResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.BIDI_STREAMING)
              .setFullMethodName(generateFullMethodName(
                  "service1.WildlifeTracker", "StreamAnimalLocations"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.lifeonland.wildlife.AnimalLocationRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.lifeonland.wildlife.AnimalLocationResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new WildlifeTrackerMethodDescriptorSupplier("StreamAnimalLocations"))
                  .build();
          }
        }
     }
     return getStreamAnimalLocationsMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static WildlifeTrackerStub newStub(io.grpc.Channel channel) {
    return new WildlifeTrackerStub(channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static WildlifeTrackerBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    return new WildlifeTrackerBlockingStub(channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static WildlifeTrackerFutureStub newFutureStub(
      io.grpc.Channel channel) {
    return new WildlifeTrackerFutureStub(channel);
  }

  /**
   */
  public static abstract class WildlifeTrackerImplBase implements io.grpc.BindableService {

    /**
     */
    public void trackAnimalLocation(com.lifeonland.wildlife.AnimalLocationRequest request,
        io.grpc.stub.StreamObserver<com.lifeonland.wildlife.AnimalLocationResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getTrackAnimalLocationMethod(), responseObserver);
    }

    /**
     */
    public io.grpc.stub.StreamObserver<com.lifeonland.wildlife.AnimalLocationRequest> streamAnimalLocations(
        io.grpc.stub.StreamObserver<com.lifeonland.wildlife.AnimalLocationResponse> responseObserver) {
      return asyncUnimplementedStreamingCall(getStreamAnimalLocationsMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getTrackAnimalLocationMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                com.lifeonland.wildlife.AnimalLocationRequest,
                com.lifeonland.wildlife.AnimalLocationResponse>(
                  this, METHODID_TRACK_ANIMAL_LOCATION)))
          .addMethod(
            getStreamAnimalLocationsMethod(),
            asyncBidiStreamingCall(
              new MethodHandlers<
                com.lifeonland.wildlife.AnimalLocationRequest,
                com.lifeonland.wildlife.AnimalLocationResponse>(
                  this, METHODID_STREAM_ANIMAL_LOCATIONS)))
          .build();
    }
  }

  /**
   */
  public static final class WildlifeTrackerStub extends io.grpc.stub.AbstractStub<WildlifeTrackerStub> {
    private WildlifeTrackerStub(io.grpc.Channel channel) {
      super(channel);
    }

    private WildlifeTrackerStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected WildlifeTrackerStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new WildlifeTrackerStub(channel, callOptions);
    }

    /**
     */
    public void trackAnimalLocation(com.lifeonland.wildlife.AnimalLocationRequest request,
        io.grpc.stub.StreamObserver<com.lifeonland.wildlife.AnimalLocationResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getTrackAnimalLocationMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public io.grpc.stub.StreamObserver<com.lifeonland.wildlife.AnimalLocationRequest> streamAnimalLocations(
        io.grpc.stub.StreamObserver<com.lifeonland.wildlife.AnimalLocationResponse> responseObserver) {
      return asyncBidiStreamingCall(
          getChannel().newCall(getStreamAnimalLocationsMethod(), getCallOptions()), responseObserver);
    }
  }

  /**
   */
  public static final class WildlifeTrackerBlockingStub extends io.grpc.stub.AbstractStub<WildlifeTrackerBlockingStub> {
    private WildlifeTrackerBlockingStub(io.grpc.Channel channel) {
      super(channel);
    }

    private WildlifeTrackerBlockingStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected WildlifeTrackerBlockingStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new WildlifeTrackerBlockingStub(channel, callOptions);
    }

    /**
     */
    public com.lifeonland.wildlife.AnimalLocationResponse trackAnimalLocation(com.lifeonland.wildlife.AnimalLocationRequest request) {
      return blockingUnaryCall(
          getChannel(), getTrackAnimalLocationMethod(), getCallOptions(), request);
    }
  }

  /**
   */
  public static final class WildlifeTrackerFutureStub extends io.grpc.stub.AbstractStub<WildlifeTrackerFutureStub> {
    private WildlifeTrackerFutureStub(io.grpc.Channel channel) {
      super(channel);
    }

    private WildlifeTrackerFutureStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected WildlifeTrackerFutureStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new WildlifeTrackerFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.lifeonland.wildlife.AnimalLocationResponse> trackAnimalLocation(
        com.lifeonland.wildlife.AnimalLocationRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getTrackAnimalLocationMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_TRACK_ANIMAL_LOCATION = 0;
  private static final int METHODID_STREAM_ANIMAL_LOCATIONS = 1;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final WildlifeTrackerImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(WildlifeTrackerImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_TRACK_ANIMAL_LOCATION:
          serviceImpl.trackAnimalLocation((com.lifeonland.wildlife.AnimalLocationRequest) request,
              (io.grpc.stub.StreamObserver<com.lifeonland.wildlife.AnimalLocationResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_STREAM_ANIMAL_LOCATIONS:
          return (io.grpc.stub.StreamObserver<Req>) serviceImpl.streamAnimalLocations(
              (io.grpc.stub.StreamObserver<com.lifeonland.wildlife.AnimalLocationResponse>) responseObserver);
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class WildlifeTrackerBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    WildlifeTrackerBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return com.lifeonland.wildlife.WildlifeTrackerProto.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("WildlifeTracker");
    }
  }

  private static final class WildlifeTrackerFileDescriptorSupplier
      extends WildlifeTrackerBaseDescriptorSupplier {
    WildlifeTrackerFileDescriptorSupplier() {}
  }

  private static final class WildlifeTrackerMethodDescriptorSupplier
      extends WildlifeTrackerBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    WildlifeTrackerMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (WildlifeTrackerGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new WildlifeTrackerFileDescriptorSupplier())
              .addMethod(getTrackAnimalLocationMethod())
              .addMethod(getStreamAnimalLocationsMethod())
              .build();
        }
      }
    }
    return result;
  }
}
