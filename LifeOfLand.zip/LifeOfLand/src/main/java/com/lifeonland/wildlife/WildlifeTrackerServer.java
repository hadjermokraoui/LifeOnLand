package com.lifeonland.wildlife;

import java.io.IOException;
import java.net.InetAddress;
import java.util.logging.Logger;

import javax.jmdns.JmDNS;
import javax.jmdns.ServiceInfo;

import com.lifeonland.utils.ServiceRegister;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;

// Import generated classes from .proto
import com.lifeonland.wildlife.WildlifeTrackerProto;
import com.lifeonland.wildlife.WildlifeTrackerGrpc;
import com.lifeonland.wildlife.AnimalLocationRequest;
import com.lifeonland.wildlife.AnimalLocationResponse;



public class WildlifeTrackerServer extends WildlifeTrackerGrpc.WildlifeTrackerImplBase {
	
	
		private static final Logger logger = Logger.getLogger(WildlifeTrackerServer.class.getName());
		
		public static void main(String[] args) throws IOException, InterruptedException {
			
		 WildlifeTrackerServer wildlifeTrackerServer = new WildlifeTrackerServer();
		 
			int port = 50051;
	
			try {
				
				Server server = ServerBuilder.forPort(50051)
		                .addService(new WildlifeTrackerServer())
		                .build()
		                .start();

		        System.out.println("WildlifeTrackerService started on port 50051");
		        
		        // Register with jmDNS
		       ServiceRegister.register("_wildlifetracker._tcp.local.", "WildlifeService", port);

		        server.awaitTermination();

				 
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    
		    logger.info("Server started, listening on " + port);
		    		    
		   
		}
	
	
	

        @Override
        public void trackAnimalLocation(AnimalLocationRequest request, StreamObserver<AnimalLocationResponse> responseObserver) {
            String message = "Animal " + request.getAnimalId() + " is in a safe zone.";

            if (isRestrictedArea(request.getLatitude(), request.getLongitude())) {
                message = "Alert! Animal " + request.getAnimalId() + " entered a restricted area!";
            }

            AnimalLocationResponse response = AnimalLocationResponse.newBuilder().setMessage(message).build();
            responseObserver.onNext(response);
            responseObserver.onCompleted();
        }

        @Override
        public StreamObserver<AnimalLocationRequest> streamAnimalLocations(StreamObserver<AnimalLocationResponse> responseObserver) {
            return new StreamObserver<AnimalLocationRequest>() {
                @Override
                public void onNext(AnimalLocationRequest request) {
                    String message = isRestrictedArea(request.getLatitude(), request.getLongitude())
                            ? "Alert! Animal " + request.getAnimalId() + " entered a restricted area!"
                            : "Animal " + request.getAnimalId() + " is moving safely.";

                    responseObserver.onNext(AnimalLocationResponse.newBuilder().setMessage(message).build());
                }

                @Override
                public void onError(Throwable t) {
                    System.err.println("Stream error: " + t.getMessage());
                }

                @Override
                public void onCompleted() {
                    responseObserver.onCompleted();
                }
            };
        }

        private boolean isRestrictedArea(double lat, double lon) {
            return lat > 25.0 && lon > 36.0;  
        }
    }
